<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>
<!DOCTYPE boost_serialization>
<boost_serialization signature="serialization::archive" version="10">
<object class_id="0" tracking_level="0" version="1">
	<mName></mName>
	<mEvolutionModel class_id="2" tracking_level="0" version="1">
		<mType>0</mType>
		<mTournamentSize>10</mTournamentSize>
		<mEvaluationTime>20</mEvaluationTime>
		<mPhase>0</mPhase>
		<mPopulationModels class_id="3" tracking_level="0" version="0">
			<count>0</count>
			<item_version>0</item_version>
		</mPopulationModels>
		<mCurrentPopulationIndex>0</mCurrentPopulationIndex>
		<mCurrentCreatureIndex>0</mCurrentCreatureIndex>
	</mEvolutionModel>
	<mEnvironmentModel class_id="1" tracking_level="1" version="0" object_id="_0">
		<EnvironmentModel class_id="4" tracking_level="0" version="1">
			<mType>2</mType>
			<mPhysicsController class_id="5" tracking_level="1" version="1" object_id="_1">
				<PhysicsController class_id="6" tracking_level="1" version="1" object_id="_2">
					<mPhysicsPaused>0</mPhysicsPaused>
					<mPhysicsStepped>0</mPhysicsStepped>
					<mSimulationSpeed>1</mSimulationSpeed>
					<mPhysicsPaused>0</mPhysicsPaused>
					<mPhysicsModelType>0</mPhysicsModelType>
					<mEnvironmentType>0</mEnvironmentType>
				</PhysicsController>
			</mPhysicsController>
			<mEnvironmentPhysics class_id="7" tracking_level="1" version="1" object_id="_3">
				<EnvironmentBt class_id="8" tracking_level="0" version="1">
					<EnvironmentPhysics class_id="9" tracking_level="0" version="1"></EnvironmentPhysics>
				</EnvironmentBt>
			</mEnvironmentPhysics>
		</EnvironmentModel>
	</mEnvironmentModel>
	<mEpochs class_id="10" tracking_level="0" version="0">
		<count>1</count>
		<item_version>0</item_version>
		<item class_id="11" tracking_level="1" version="1" object_id="_4">
			<mFitnessEnabled>0</mFitnessEnabled>
			<mJuryTypes class_id="12" tracking_level="0" version="0">
				<count>2</count>
				<item_version>0</item_version>
				<item>0</item>
				<item>3</item>
			</mJuryTypes>
			<mWeights>
				<count>2</count>
				<item_version>0</item_version>
				<item>2</item>
				<item>1</item>
			</mWeights>
			<mSortOrders>
				<count>2</count>
				<item>1</item>
				<item>0</item>
			</mSortOrders>
			<mCurrentFitness>0</mCurrentFitness>
			<mEndingAtFitness>0</mEndingAtFitness>
			<mGenerationsEnabled>0</mGenerationsEnabled>
			<mCurrentGeneration>0</mCurrentGeneration>
			<mEndingAtGeneration>0</mEndingAtGeneration>
		</item>
	</mEpochs>
	<mCurrentEpoch>0</mCurrentEpoch>
</object>
</boost_serialization>

